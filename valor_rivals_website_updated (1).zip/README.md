# VALØR Roblox Rivals Website

Free static website using the uploaded VALØR logo.

## Files
- index.html — the complete website
- valor-logo.png — uploaded logo

## Customize
Open `index.html` and replace:
- the Roblox button URL
- the Discord button URL
- the placeholder player/team/win stats
- the About/Community text

## Free hosting
Upload these two files to GitHub Pages or Cloudflare Pages.
