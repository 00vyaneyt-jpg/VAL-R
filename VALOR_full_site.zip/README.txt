VALØR — Full Community Website
================================

WHAT'S INSIDE
-------------
index.html      - the full site (single file, all sections)
assets/logo.png - your crest logo, used as favicon + nav + hero mark

HOW TO UPLOAD TO GITHUB
------------------------
1. Go to your repo: https://github.com/00vyaneyt-jpg/VAL-R
2. Click "Add file" -> "Upload files"
3. Drag in index.html AND the whole assets/ folder (keep the folder structure —
   assets/logo.png must stay at that exact path for the logo to load)
4. Commit directly to the main branch
5. Your site updates automatically at https://00vyaneyt-jpg.github.io/VAL-R/

WHAT WAS ADDED (on top of your original site)
-----------------------------------------------
- War Roster & Rankings   (#roster)  — competitive lineup with rank/rating placeholders
- Clan Wars ledger        (#wars)    — war status banner, W/L record, war history table
- Events & Tournaments    (#events)  — scrim/tournament calendar cards
- Trophy Case             (#trophies)— achievements/milestones
- Join the Roster         (#apply)   — 4-step application flow
- Media                   (#media)   — clip/highlight embed placeholders
- Partnerships            (#partners)— affiliated clan slots
- Verification Notice     (#verify)  — anti-impersonation warning
- Changelog                (#changelog) — site/community update log
- Footer social icons (Discord/YouTube/TikTok/X — update the href="#" links)
- Your crest logo wired in as favicon, nav mark, and hero image

EDITING PLACEHOLDERS
---------------------
Search index.html for these markers and replace with real info as you have it:
- "Player Slot" / "Add IGN here"  -> real roster names + stats
- "No wars logged yet"             -> add a .ledger-row per completed war
- "TBD" event dates                -> real scrim/tournament dates
- "Add your first tournament result" etc. -> real achievements
- "Add clip"                       -> replace .clip divs with <iframe> embeds
- "Partner Slot"                   -> real partnered clan names
- footer href="#" social links     -> your real YouTube/TikTok/X URLs

Everything uses the same dark, monochrome VALØR style as your original site —
no new fonts or colors except a small gold accent (matching your logo's halo)
used only for the Trophy Case and Verification Notice.
